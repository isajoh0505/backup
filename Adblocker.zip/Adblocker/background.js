chrome.webNavigation.onCompleted.addListener(function() {
  chrome.storage.local.get(["enabled"], function(result) {
    var enabled = result.enabled;
    if(enabled) {
      chrome.tabs.executeScript(null, {file: "main.js"});
    }
  });
});