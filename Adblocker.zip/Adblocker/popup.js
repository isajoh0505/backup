var checkbox = document.getElementById("enabled");
var bg = chrome.extension.getBackgroundPage();
bg.chrome.storage.local.get(["enabled", "whitelist"], function(result) {
  checkbox.checked = result.enabled;
  
  var wl = result.whitelist.split(" ");
  wl.splice(wl.length - 1, 1);
  for(var i = 0; i < wl.length; i++) {
    addWhitelistItem(wl[i]);
  }
});

addEventListener("unload", function() {
  var wl = "";
  var texts = document.getElementsByClassName("whitelist-textitem");
  for(var i = 0; i < texts.length; i++) {
    wl += texts[i].value;
    wl += " ";
  }
  bg.chrome.storage.local.set({enabled: checkbox.checked, whitelist: wl}, function() {});
});

document.getElementById("add-whitelist-item").addEventListener("click", addWhitelistItem);

function addWhitelistItem(name) {
  var item = document.createElement("li");
  document.getElementById("whitelist-list").insertBefore(item, document.getElementById("add-whitelist-item-list-item"));
  var input = document.createElement("input");
  input.type = "text";
  input.setAttribute("spellcheck", "false");
  input.setAttribute("class", "whitelist-textitem");
  if(typeof name == "string") {
    input.setAttribute("value", name);
  }
  item.appendChild(input);
  var del = document.createElement("button");
  del.setAttribute("class", "remove");
  del.innerHTML = "&#x2715;";
  del.addEventListener("click", function () {
    this.parentNode.parentNode.removeChild(this.parentNode);
  });
  item.appendChild(del);
}

// Cool moving background
window.onload = function() {
  // Wait 50ms for window to load correctly
  setTimeout(start, 50);
}
function start() {
  var c = document.getElementById("c");
  c.width = window.innerWidth;
  c.height = window.innerHeight;
  var ctx = c.getContext("2d");

  var time = window.performance.now();
  var particles = [];
  var spawners = [];
  for(var i = 0; i < 60; i++) {
    spawners.push({x: Math.random() * c.width * 3 - c.width, y: Math.random() * c.height * 3 - c.height, col: 75});
  }

  setInterval(update, 1000 / 15);
  function update() {
    time = window.performance.now();
    for(var i = 0; i < spawners.length; i++) {
      if(spawners[i].x > c.width * 2) {
        spawners[i].x = -c.width;
      }
      if(spawners[i].x < -c.width) {
        spawners[i].x = c.width * 2;
      }
      if(spawners[i].y > c.height * 2) {
        spawners[i].y = -c.height;
      }
      if(spawners[i].y > c.height * 2) {
        spawners[i].y = -c.height;
      }

      particles.push({x: spawners[i].x, y: spawners[i].y, time: 0, col: spawners[i].col, r: spawners[i].r});
      spawners[i].x += (noise2d(i * 126.313, time / 2000 + 123) - 0.5) * 5;
      spawners[i].y += (noise2d(i * 57.832, time / 2000) - 0.5) * 5;
      spawners[i].col = noise2d(i * 16.323, time / 2000) * 35 + 25;
      spawners[i].r = noise2d(i * 76.792, time / 2000) * 50 + 5;
    }

    ctx.clearRect(0, 0, c.width, c.height);

    for(var i = 0; i < particles.length; i++) {
      ctx.beginPath();
      ctx.ellipse(particles[i].x, particles[i].y, particles[i].r, particles[i].r, 0, 0, Math.PI * 2);
      ctx.closePath();
      ctx.fillStyle = "rgb(" + (200 - particles[i].col) + ", " + (200 - particles[i].col) + ", 255, " + (1 - particles[i].time / 25) + ")";
      ctx.fill();

      if(particles[i].time >= 25) {
        particles.splice(i, 1);
      }

      particles[i].time++;
    }
  }


  // Noise
  function rand(x) {
    return (Math.abs(x) * 3.834525 * Math.abs(x + 2.1267) * 7.2168745 * Math.abs(x + 0.734) + 25.273783) % 1;
  }

  function rand2(x, y) {
    return rand(rand(x) + y);
  }

  function fract(x) {
    return x - Math.floor(x);
  }

  function lerp(a, b, i) {
    return a * (1 - i) + b * i;
  }

  function ease(x) {
    return Math.cos(x * Math.PI + Math.PI) / 2 + 0.5;
  }

  function noise2d(x, y) {
    var u = lerp(rand2(Math.floor(x), Math.floor(y)), rand2(Math.floor(x) + 1, Math.floor(y)), ease(fract(x)));
    var v = lerp(rand2(Math.floor(x), Math.floor(y) + 1), rand2(Math.floor(x) + 1, Math.floor(y) + 1), ease(fract(x)));
    var res = lerp(u, v, ease(fract(y)));
    return res;
  }
}