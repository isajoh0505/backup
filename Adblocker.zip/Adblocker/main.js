chrome.storage.local.get(["whitelist"], function(result) {
  var wl = result.whitelist.split(" ");
  wl.splice(wl.length - 1, 1);
  
  var run = true;
  for(var i = 0; i < wl.length; i++) {
    if(window.location.href.search(wl[i]) != -1) {
      run = false;
    }
  }

  if(!window.adblockerInjected && run) {
    window.adblockerInjected = true;

    var searchString = ""; 
    var elements = ["div", "iframe"];
    var attributes = ["class", "id"];
    var keywords = ["*=cpmstar", "*=ads", "*=-ad-", "*=_ad_", "|=ad", "*=aswift", "^=ad-", "^=ad_", "$=-ad", "$=_ad"];
    for(var i = 0; i < elements.length; i++) {
      for(var j = 0; j < attributes.length; j++) {
        for(var k = 0; k < keywords.length; k++) {
          if(i > 0 || j > 0 || k > 0) {
            searchString += ", ";
          }
          searchString += elements[i] + "[" + attributes[j] + keywords[k] + "]";
        }
      }
    }

    setInterval(update, 1000);
    update();
    function update() {
      if(window.location.href.search("youtube.com") != -1) {
        if(document.getElementById("movie_player").getAttribute("class").search("ad-showing") != -1) {
          var vid = document.getElementsByClassName("html5-main-video")[0];
          vid.currentTime = vid.duration;
        }
      } else {
        var ads = document.querySelectorAll(searchString);
        //console.log(ads);
        for(var i = 0; i < ads.length; i++) {
          ads[i].setAttribute("style", "display: none !important");
        }
      }
    }
  }
});